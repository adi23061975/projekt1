<?php return array (
  'users.users-table-view' => 'App\\Http\\Livewire\\Users\\UsersTableView',
);