
<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['icon' => 'chevron-down']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['icon' => 'chevron-down']); ?>
<?php foreach (array_filter((['icon' => 'chevron-down']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<button
  class="border border-transparent hover:border-gray-300 focus:border-gray-300 focus:outline-none flex items-center gap-1 text-xs px-3 py-2 rounded hover:shadow-sm font-medium"
>
  <?php echo e($slot); ?>

  <?php if($icon): ?>
    <i data-feather="<?php echo e($icon); ?>" class="w-4 h-4"></i>
  <?php endif; ?>
</button>
<?php /**PATH /var/www/html/vendor/laravel-views/laravel-views/src/../resources/views/components/buttons/select.blade.php ENDPATH**/ ?>