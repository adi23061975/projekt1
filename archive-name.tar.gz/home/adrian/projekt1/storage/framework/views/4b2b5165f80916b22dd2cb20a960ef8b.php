

<?php $__env->startComponent('laravel-views::components.form.select', [
  'name' => "filters[{$view->id}]",
  'model' => "filters.{$view->id}",
  'options' => array_merge(['--' => ''], $view->options()),
]); ?>
<?php echo $__env->renderComponent(); ?><?php /**PATH /var/www/html/vendor/laravel-views/laravel-views/src/../resources/views/components/filters/select-filter.blade.php ENDPATH**/ ?>