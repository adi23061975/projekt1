<span <?php echo e($attributes->merge(['class' => 'animate-spin'])); ?>>
  <?php echo UI::icon('loader', '', 'text-gray-500'); ?>

</span><?php /**PATH /var/www/html/vendor/laravel-views/laravel-views/src/../resources/views/components/loading.blade.php ENDPATH**/ ?>