<?php if (isset($component)) { $__componentOriginal9ed5676fe396ee443dc1c5dc04ac854d = $component; } ?>
<?php $component = LaravelViews\Views\Components\DynamicComponent::resolve(['view' => $view,'data' => $data] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('lv-dynamic-component'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(LaravelViews\Views\Components\DynamicComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ed5676fe396ee443dc1c5dc04ac854d)): ?>
<?php $component = $__componentOriginal9ed5676fe396ee443dc1c5dc04ac854d; ?>
<?php unset($__componentOriginal9ed5676fe396ee443dc1c5dc04ac854d); ?>
<?php endif; ?>
<?php /**PATH /var/www/html/vendor/laravel-views/laravel-views/src/../resources/views/core/dynamic-component.blade.php ENDPATH**/ ?>