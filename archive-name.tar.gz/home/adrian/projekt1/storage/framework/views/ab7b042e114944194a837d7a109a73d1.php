
<div class="text-left mb-4">
  <?php if(isset($label)): ?>
    <label class="block">
      <?php echo e($label); ?>

    </label>
  <?php endif; ?>
  <div class="inline-block relative w-full">
    <select
      class="block appearance-none w-full bg-white border border-gray-300 hover:border-gray-500 px-4 py-2 pr-8 rounded leading-tight focus:outline-none"
      <?php echo e(isset($model) ? 'wire:model='.$model : ''); ?> name="<?php echo e($name); ?>" class="<?php echo e($class ?? ''); ?>"
    >
      <?php if(count($options)): ?>
        <?php $__currentLoopData = $options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($value); ?>" <?php echo e(isset($selected) && $selected != '' && $selected == $value ? 'selected' : ''); ?>>
            <?php echo e($option); ?>

          </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php endif; ?>
    </select>

    
    <div class="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-gray-700">
      <i data-feather="chevron-down" class="w-4 h-4"></i>
    </div>
  </div>
</div><?php /**PATH /var/www/html/vendor/laravel-views/laravel-views/src/../resources/views/components/form/select.blade.php ENDPATH**/ ?>